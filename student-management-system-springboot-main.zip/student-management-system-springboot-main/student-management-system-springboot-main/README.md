# Student Management System

A web-based Student Management System developed using Java, Spring Boot, Spring Data JPA, Hibernate, MySQL, and Thymeleaf. The application provides a simple interface to manage student records efficiently.

## Features

- Add new student records
- View all registered students
- Update existing student information
- Delete student records
- Store student information in a MySQL database
- Dynamic web pages using Thymeleaf
- Automatic database table management using Hibernate

## Technologies Used

- Java 17
- Spring Boot 3.0.4
- Spring Data JPA
- Hibernate
- MySQL
- Thymeleaf
- HTML and CSS
- Maven

## Project Structure

```text
student-management-system/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── net/
│   │   │       └── academic/
│   │   │           └── sms/
│   │   │               ├── controller/
│   │   │               ├── entity/
│   │   │               ├── repository/
│   │   │               ├── service/
│   │   │               └── StudentManagementSystemApplication.java
│   │   └── resources/
│   │       ├── templates/
│   │       └── application.properties
│   └── test/
├── pom.xml
└── README.md
```

## Prerequisites

Make sure you have installed:

- JDK 17
- Apache Maven
- MySQL Server
- MySQL Workbench (optional)
- VS Code or IntelliJ IDEA

## Database Configuration

First, create a database in MySQL:

```sql
CREATE DATABASE sms;
```

Next, configure `src/main/resources/application.properties`:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/sms?useSSL=false&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=YOUR_MYSQL_PASSWORD

spring.jpa.hibernate.ddl-auto=update
spring.jpa.show-sql=true
spring.jpa.properties.hibernate.dialect=org.hibernate.dialect.MySQLDialect
```

Replace `YOUR_MYSQL_PASSWORD` with your local MySQL password. Never upload your actual password to GitHub.

## How to Run the Project

**Step 1: Clone the repository**

```bash
git clone YOUR_GITHUB_REPOSITORY_URL
```

**Step 2: Navigate to the project folder**

```bash
cd student-management-system
```

**Step 3: Build the project**

```bash
mvn clean install
```

**Step 4: Run the application**

```bash
mvn spring-boot:run
```

**Step 5: Open in your browser**

```text
http://localhost:8080
```

## Learning Outcomes

Through this project, I gained practical experience in:

- Java application development
- Spring Boot framework
- MVC architecture
- CRUD operations
- Spring Data JPA and Hibernate
- MySQL database integration
- Maven dependency management
- Backend and frontend integration

## Author

**Deependra Verma**

MCA Graduate | Java Developer